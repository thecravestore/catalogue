<?php

if ( ! function_exists('is_plugin_active')) { include_once( ABSPATH . 'wp-admin/includes/plugin.php' ); }
//Elementor Addons File
function hastech_addons_required(){
    
    require_once PARLO_PLUGINS_PATH.'include/elementor/testimonial.php';
    require_once PARLO_PLUGINS_PATH.'include/elementor/service.php';
    require_once PARLO_PLUGINS_PATH.'include/elementor/latest_blog.php';
    require_once PARLO_PLUGINS_PATH.'include/elementor/teammember.php';

    if( is_plugin_active('woocommerce/woocommerce.php') ){
        require_once PARLO_PLUGINS_PATH.'include/elementor/collention.php';
    }
}
add_action('elementor/widgets/widgets_registered','hastech_addons_required');